<script lang="ts">
  import { t } from '$lib/stores/lang';
  import { booking, resetBooking } from '$lib/stores/booking';

  const WHATSAPP_URL = 'https://wa.me/1514XXXXXXX';

  const ref = $booking.reference_no;

  function newBooking() {
    resetBooking();
    window.location.href = '/';
  }
</script>

<svelte:head>
  <title>Booking Received — Shipway237</title>
</svelte:head>

<div class="success-page">
  <div class="success-card">
    <div class="success-icon">✅</div>
    <h1 class="success-title">{$t.success.title}</h1>
    <p class="success-message">{$t.success.message}</p>

    {#if ref}
      <div class="reference-box">
        <span class="reference-label">{$t.success.reference}</span>
        <span class="reference-no">{ref}</span>
      </div>
    {/if}

    <div class="success-actions">
      <a href={WHATSAPP_URL} target="_blank" class="btn-whatsapp">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg>
        {$t.success.whatsapp}
      </a>
      <button class="btn-new" onclick={newBooking}>
        {$t.success.new_booking}
      </button>
    </div>
  </div>
</div>

<style>
  .success-page {
    min-height: calc(100vh - 64px);
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 2rem 1rem;
  }

  .success-card {
    max-width: 480px;
    width: 100%;
    text-align: center;
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 1.25rem;
  }

  .success-icon { font-size: 3.5rem; }

  .success-title {
    font-family: 'Barlow Condensed', sans-serif;
    font-size: 2rem;
    font-weight: 700;
    text-transform: uppercase;
    color: #1a1a1a;
  }

  .success-message {
    font-size: 1rem;
    color: var(--gray);
    line-height: 1.6;
  }

  .reference-box {
    background: var(--red-light);
    border: 1.5px solid rgba(180,40,20,0.2);
    border-radius: var(--radius);
    padding: 1rem 2rem;
    display: flex;
    flex-direction: column;
    gap: 0.25rem;
    width: 100%;
  }

  .reference-label {
    font-size: 0.75rem;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 1px;
    color: var(--red);
  }

  .reference-no {
    font-family: 'Barlow Condensed', sans-serif;
    font-size: 1.75rem;
    font-weight: 700;
    color: var(--red-deeper);
    letter-spacing: 1px;
  }

  .success-actions {
    display: flex;
    flex-direction: column;
    gap: 0.75rem;
    width: 100%;
  }

  .btn-whatsapp {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 0.5rem;
    padding: 0.875rem;
    background: #1a7c3e;
    color: #fff;
    text-decoration: none;
    border-radius: var(--radius);
    font-weight: 600;
    font-size: 0.95rem;
    transition: background 0.15s;
  }

  .btn-whatsapp:hover { background: #155f2f; }

  .btn-new {
    padding: 0.875rem;
    background: none;
    border: 1.5px solid var(--gray-light);
    border-radius: var(--radius);
    font-family: 'Barlow', sans-serif;
    font-size: 0.95rem;
    font-weight: 500;
    color: var(--gray);
    cursor: pointer;
    transition: all 0.15s;
  }

  .btn-new:hover { border-color: var(--red); color: var(--red); }
</style>
