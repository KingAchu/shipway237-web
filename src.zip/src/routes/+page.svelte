<script lang="ts">
  import { t } from '$lib/stores/lang';
  import { booking } from '$lib/stores/booking';
  import { goto } from '$app/navigation';
  import type { ServiceType } from '$lib/stores/booking';

  const WHATSAPP_URL = 'https://wa.me/1514XXXXXXX';

  const services: { type: ServiceType; icon: string }[] = [
    { type: 'vehicle',     icon: '🚗' },
    { type: 'barrel',      icon: '📦' },
    { type: 'procurement', icon: '🛒' },
  ];

  function selectService(type: ServiceType) {
    booking.update(b => ({ ...b, service_type: type }));
    goto(`/book/${type}`);
  }
</script>

<svelte:head>
  <title>Shipway237 — Transport & Logistics | Cameroon ↔ Canada</title>
  <meta name="description" content="Reliable shipping from Montreal and Toronto to Cameroon. Cars, barrels, and procurement services." />
</svelte:head>

<!-- Hero -->
<section class="hero">
  <div class="hero-bg"></div>
  <div class="hero-inner">
    <div class="hero-content">
      <span class="hero-label">{$t.home.hero_label}</span>
      <h1 class="hero-title">{$t.home.hero_title}</h1>
      <p class="hero-sub">{$t.home.hero_sub}</p>
      <div class="hero-ctas">
        <a href="/book/vehicle" class="btn-primary">{$t.home.cta_book}</a>
        <a href={WHATSAPP_URL} target="_blank" class="btn-whatsapp">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg>
          {$t.home.cta_whatsapp}
        </a>
      </div>
    </div>
    <div class="hero-visual">
      <div class="hero-badge">
        <span class="badge-num">237</span>
        <span class="badge-text">Cameroun</span>
      </div>
      <div class="hero-route">
        <span class="route-city">Montréal</span>
        <span class="route-arrow">✈</span>
        <span class="route-city">Toronto</span>
        <span class="route-arrow">→</span>
        <span class="route-city">Douala</span>
      </div>
    </div>
  </div>
</section>

<!-- Service selector -->
<section class="services">
  <div class="services-inner">
    <h2 class="section-title">{$t.home.select_service}</h2>
    <div class="service-cards">
      {#each services as svc}
        <button
          class="service-card"
          onclick={() => selectService(svc.type)}
        >
          <span class="service-icon">{svc.icon}</span>
          <span class="service-name">{$t.services[svc.type]}</span>
          <span class="service-desc">{$t.services[`${svc.type}_desc`]}</span>
          <span class="service-arrow">→</span>
        </button>
      {/each}
    </div>
  </div>
</section>

<!-- Trust strip -->
<section class="trust">
  <div class="trust-inner">
    <div class="trust-item">
      <span class="trust-icon">🇨🇦</span>
      <span>Montreal & Toronto pickup</span>
    </div>
    <div class="trust-divider"></div>
    <div class="trust-item">
      <span class="trust-icon">🇨🇲</span>
      <span>Door-to-door in Cameroon</span>
    </div>
    <div class="trust-divider"></div>
    <div class="trust-item">
      <span class="trust-icon">💬</span>
      <span>WhatsApp updates</span>
    </div>
    <div class="trust-divider"></div>
    <div class="trust-item">
      <span class="trust-icon">🔒</span>
      <span>Secure payments</span>
    </div>
  </div>
</section>

<style>
  /* ── Hero ── */
  .hero {
    position: relative;
    overflow: hidden;
    background: #1a1a1a;
    color: #fff;
    padding: 5rem 1.5rem 4rem;
  }

  .hero-bg {
    position: absolute;
    inset: 0;
    background: linear-gradient(135deg, #7A0F0F 0%, #1a1a1a 60%);
    opacity: 0.9;
  }

  .hero-inner {
    position: relative;
    max-width: 1200px;
    margin: 0 auto;
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 3rem;
  }

  .hero-content {
    max-width: 560px;
  }

  .hero-label {
    display: inline-block;
    background: rgba(180, 40, 20, 0.4);
    border: 1px solid rgba(180, 40, 20, 0.6);
    color: #ffb3a7;
    font-size: 0.8rem;
    font-weight: 600;
    letter-spacing: 1.5px;
    text-transform: uppercase;
    padding: 0.3rem 0.85rem;
    border-radius: 20px;
    margin-bottom: 1.25rem;
  }

  .hero-title {
    font-family: 'Barlow Condensed', sans-serif;
    font-size: clamp(2.5rem, 6vw, 4rem);
    font-weight: 700;
    line-height: 1.05;
    color: #fff;
    text-transform: uppercase;
    letter-spacing: -0.5px;
    margin-bottom: 1rem;
  }

  .hero-sub {
    font-size: 1.05rem;
    color: #ccc;
    line-height: 1.6;
    margin-bottom: 2rem;
  }

  .hero-ctas {
    display: flex;
    gap: 1rem;
    flex-wrap: wrap;
  }

  .btn-primary {
    background: var(--red);
    color: #fff;
    text-decoration: none;
    padding: 0.875rem 2rem;
    border-radius: var(--radius);
    font-weight: 600;
    font-size: 0.95rem;
    transition: background 0.15s, transform 0.1s;
    display: inline-block;
  }

  .btn-primary:hover {
    background: var(--red-dark);
    transform: translateY(-1px);
  }

  .btn-whatsapp {
    background: #1a7c3e;
    color: #fff;
    text-decoration: none;
    padding: 0.875rem 1.5rem;
    border-radius: var(--radius);
    font-weight: 600;
    font-size: 0.95rem;
    display: inline-flex;
    align-items: center;
    gap: 0.5rem;
    transition: background 0.15s, transform 0.1s;
  }

  .btn-whatsapp:hover {
    background: #155f2f;
    transform: translateY(-1px);
  }

  /* ── Hero visual ── */
  .hero-visual {
    flex-shrink: 0;
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 1.5rem;
  }

  .hero-badge {
    width: 120px;
    height: 120px;
    border-radius: 50%;
    background: var(--red);
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    border: 4px solid rgba(255,255,255,0.15);
  }

  .badge-num {
    font-family: 'Barlow Condensed', sans-serif;
    font-size: 2.5rem;
    font-weight: 700;
    color: #fff;
    line-height: 1;
  }

  .badge-text {
    font-size: 0.7rem;
    color: rgba(255,255,255,0.8);
    letter-spacing: 1px;
    text-transform: uppercase;
  }

  .hero-route {
    display: flex;
    align-items: center;
    gap: 0.5rem;
    font-size: 0.8rem;
    color: #999;
  }

  .route-city {
    color: #ccc;
    font-weight: 500;
  }

  .route-arrow {
    color: var(--red);
  }

  /* ── Services ── */
  .services {
    padding: 4rem 1.5rem;
    background: #fff;
  }

  .services-inner {
    max-width: 1200px;
    margin: 0 auto;
  }

  .section-title {
    font-family: 'Barlow Condensed', sans-serif;
    font-size: 1.75rem;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    color: #1a1a1a;
    margin-bottom: 2rem;
  }

  .service-cards {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
    gap: 1.25rem;
  }

  .service-card {
    background: #fff;
    border: 1.5px solid var(--gray-light);
    border-radius: var(--radius-lg);
    padding: 2rem 1.75rem;
    text-align: left;
    cursor: pointer;
    transition: border-color 0.2s, transform 0.15s, box-shadow 0.2s;
    display: flex;
    flex-direction: column;
    gap: 0.5rem;
    font-family: 'Barlow', sans-serif;
  }

  .service-card:hover {
    border-color: var(--red);
    transform: translateY(-3px);
    box-shadow: 0 8px 24px rgba(180, 40, 20, 0.1);
  }

  .service-icon {
    font-size: 2rem;
    margin-bottom: 0.25rem;
  }

  .service-name {
    font-size: 1.2rem;
    font-weight: 700;
    color: #1a1a1a;
    font-family: 'Barlow Condensed', sans-serif;
    text-transform: uppercase;
    letter-spacing: 0.5px;
  }

  .service-desc {
    font-size: 0.875rem;
    color: var(--gray);
    line-height: 1.5;
    flex: 1;
  }

  .service-arrow {
    font-size: 1.25rem;
    color: var(--red);
    margin-top: 0.5rem;
    transition: transform 0.15s;
  }

  .service-card:hover .service-arrow {
    transform: translateX(4px);
  }

  /* ── Trust strip ── */
  .trust {
    background: var(--red-light);
    border-top: 1px solid rgba(180, 40, 20, 0.15);
    border-bottom: 1px solid rgba(180, 40, 20, 0.15);
    padding: 1.25rem 1.5rem;
  }

  .trust-inner {
    max-width: 1200px;
    margin: 0 auto;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 1.5rem;
    flex-wrap: wrap;
  }

  .trust-item {
    display: flex;
    align-items: center;
    gap: 0.5rem;
    font-size: 0.85rem;
    font-weight: 500;
    color: var(--red-deeper);
  }

  .trust-icon {
    font-size: 1.1rem;
  }

  .trust-divider {
    width: 1px;
    height: 20px;
    background: rgba(180, 40, 20, 0.25);
  }

  /* ── Mobile ── */
  @media (max-width: 768px) {
    .hero-visual { display: none; }
    .trust-divider { display: none; }
    .trust-inner { gap: 1rem; justify-content: flex-start; }
  }
</style>
